#include "SceneNode.h"

SceneNode::SceneNode(Mesh* mesh, Vector4 colour)
{
	this->mesh = mesh;
	this->colour = colour;
	boundingRadius = 1.0f;
	distanceFromCamera = 0.0f;
	parent = NULL;
	shader = NULL;
	heightMap = NULL;
	modelScale = Vector3(1, 1, 1);
	useOffset = false;
	transparent = false;
	useAltHeightMap = false;
	offset = -1.0f;
}

SceneNode::~SceneNode(void)
{
	for (unsigned int i = 0; i < children.size(); ++i)
		delete children[i];
	mesh = NULL;
	delete heightMap;
	delete shader;
}

void SceneNode::AddChild(SceneNode* s)
{
	if (this == s)
		return;
	children.push_back(s);
	s->parent = this;
}

void SceneNode::RemoveChild(SceneNode* child)
{
	for (unsigned int i = 0; i < child->children.size(); ++i)
		child->parent->AddChild(child->children[i]);
	delete child;
}

void SceneNode::DestroyChild(SceneNode* child)
{
	for (unsigned int i = 0; i < children.size(); ++i)
		DestroyChild(children[i]);
	delete child;
}

void SceneNode::Draw(/*const OGLRenderer &r*/)
{
	if (heightMap)
		heightMap->Draw();
	else if (mesh)
		mesh->Draw();
}

void SceneNode::Update(float msec) {
	if (parent)
		worldTransform = parent->worldTransform * transform;
	else
		worldTransform = transform;

	vector<float> radii;		// all the bounding radii of the child nodes
	float childMax = 0;			// max bounding radius of all the child nodes
	int i = 0;
	for (vector<SceneNode*>::iterator it = children.begin(); it != children.end(); ++it)
	{
		(*it)->Update(msec);

		float dist = (*it)->transform.GetPositionVector().Length();		// distance of child node from parent
		radii.push_back((*it)->totalRadius + dist);
		if (i > 0)
		{
			if (radii[i] > radii[i - 1])
				childMax = radii[i];
		}
		else
			childMax = radii[i];
		++i;
	}
	
	totalRadius = ((boundingRadius > childMax) ? boundingRadius : childMax);

	if (offset >= 0.0f) //rotate texture
		offset += msec / 5000.0f;
}