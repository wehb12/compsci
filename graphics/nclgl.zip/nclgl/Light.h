#pragma once

//#include "Window.h"
#include "Vector4.h"
#include "Vector3.h"

#define PI			3.141592654
#define TO_RADIANS	PI / 180

class Light
{
public:
	Light(Vector3 position, Vector4 emiColour, float radius, Vector4 specColour = Vector4(0, 0, 0, 0), int type = 0, Vector3 direction = Vector3(0, 0, 0), float angle = 0)
	{
		//pitch = 0;
		//yaw = 0;
		//roll = 0;
		if (type == 0)
		{
			this->position = position;
			this->radius = radius;
			this->direction = Vector3(0, 0, 0);
			this->intensity = 0;
		}
		else if (type == 1)
		{
			this->direction = position;
			this->intensity = radius;
			this->position = Vector3(0, 0, 0);
			this->radius = 0;
			//if (direction.z || direction.y)
			//	pitch = atan(direction.y / -direction.z) * TO_DEGREES;
			//if (direction.x || direction.z)
			//	yaw = atan(-direction.z / direction.x) * TO_DEGREES;
		}
		else if (type == 2)
		{
			if (direction == Vector3(0, 0, 0))
			{
				std::cout << "Invalid inputs for a SPOTLIGHT object, please enter a direction.\n";
				return;
			}
			if (angle == 0)
			{
				std::cout << "Invalid inputs for a SPOTLIGHT object, please enter an angle.\n";
				return;
			}
			this->position = position;
			this->radius = radius;
			this->direction = direction;
			this->angle = angle * (float)TO_RADIANS;
			this->intensity = 0;
			//if (direction.z || direction.y)
			//	pitch = atan(direction.y / -direction.z) * TO_DEGREES;
			//if (direction.x || direction.z)
			//	yaw = atan(-direction.z / direction.x) * TO_DEGREES;
		}
		else
			return;
		this->emiColour = emiColour;
		if (specColour == Vector4(0, 0, 0, 0))
			this->specColour = emiColour;
		else
			this->specColour = specColour;
		this->type = type;

		xSpeed = 100;
		ySpeed = 100;
		zSpeed = 100;
	}

	Light()
	{
		this->position = Vector3(0, 0, 0);
		this->radius = 0;
		this->direction = Vector3(0, 0, 0);
		this->intensity = 0;
		this->angle = 0;
		this->emiColour = Vector4(0, 0, 0, 0);
		this->specColour = Vector4(0, 0, 0, 0);
		this->type = -1;

		xSpeed = 100;
		ySpeed = 100;
		zSpeed = 100;
	}
	
	~Light(void) { }

	Vector3 GetPosition() const		{ if (type == 0 || type == 2) return position; else return Vector3(0, 0, 0); }
	void SetPosition(Vector3 val)	{ position = val; }
	
	float GetRadius() const			{ if (type == 0 || type == 2) return radius; else return 0; }
	void SetRadius(float val)		{ radius = val; }
	
	Vector4 GetEmiColour() const		{ return emiColour; }
	void SetEmiColour(Vector4 val)		{ emiColour = val; }

	Vector4 GetSpecColour() const		{ return specColour; }
	void SetSpecColour(Vector4 val)		{ specColour = val; }

	Vector3 GetDirection() const	{ if (type == 1 || type == 2) return direction; else return Vector3(0, 0, 0); }
	void SetDirection(Vector3 dir)	{ direction = dir; }

	float GetIntensity() const			{ if (type == 1) return intensity; else return 0; }
	void SetIntensity(float val)		{ intensity = val; type = 1; }

	float GetAngle() const		{ if (type == 2) return angle; else return 0; }
	void SetAngle(float val)	{ angle = val; type = 2; }

	void SetType(int t)		{ type = t; }
	int GetType()			{ return type; }

	int GetXSpeed() { return xSpeed; }
	int GetYSpeed() { return ySpeed; }
	int GetZSpeed() { return zSpeed; }

	//int GetYaw() { return yaw; }
	//int GetRoll() { return roll; }
	//int GetPitch() { return pitch; }

	//void SetYaw(float y) { yaw = y; }
	//void SetRoll(float r) { roll = r; }
	//void SetPitch(float p) { pitch = p; }


protected:
	Vector3 position;
	Vector4 emiColour;
	float radius;
	Vector4 specColour;

	//float	yaw;
	//float	pitch;
	//float	roll;

	int		xSpeed;
	int		ySpeed;
	int		zSpeed;

	int type;
	float intensity;
	Vector3 direction;

	float angle;	// input in degrees but stored as radians
					// user could instead specify the radius of illumination at one unit from source, if sin function proves too expensive
};