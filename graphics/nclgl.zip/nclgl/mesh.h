#pragma once

#include "../../nclgl/OGLRenderer.h"

enum MeshBuffer
{
	VERTEX_BUFFER,
	COLOUR_BUFFER,
	SPEC_COLOUR_BUFFER,
	TEXTURE_BUFFER,
	NORMAL_BUFFER,
	TANGENT_BUFFER,
	INDEX_BUFFER,
	MAX_BUFFER
};

class Mesh
{
public:
	Mesh();
	~Mesh();

	virtual void	Draw();
	static Mesh*	GenerateTriangle();
	static Mesh*	GenerateQuad();
	static Mesh*	GeneratePyramid();
	GLuint			GetColourBuffer() { return bufferObject[COLOUR_BUFFER]; }

	inline void		SetColour(Vector4 c)		{ *colours = c; }

	inline void		SetTexture(GLuint tex)		{ texture = tex; }
	inline GLuint	GetTexture()				{ return texture; }

	void	SetBumpMap(GLuint tex)	{ bumpTexture = tex; }
	GLuint	GetBumpMap()			{ return bumpTexture; }

	void SetSpecMap(GLuint tex)		{ specTexture = tex; }
	GLuint GetSpecMap()				{ return specTexture; }

	void SetGlossMap(GLuint tex)	{ glossTexture = tex; }
	GLuint GetGlossMap()			{ return glossTexture; }

protected:
	void	BufferData();
	void	GenerateNormals();
	void	GenerateTangents();
	Vector3	GenerateTangent(const Vector3 &a, const Vector3 &b,
							const Vector3 &c, const Vector2 &ta,
							const Vector2 &tb, const Vector2 &tc);

	GLuint	arrayObject;
	GLuint	bufferObject[MAX_BUFFER];
	GLuint	numVertices;
	GLuint	numIndices;
	GLuint	type;

	unsigned int*	indices;
	Vector3*		vertices;
	Vector4*		colours;
	Vector4*		specColours;
	Vector3*		normals;
	Vector3*		tangents;

	GLuint		specTexture;
	GLuint		glossTexture;
	GLuint		bumpTexture;
	GLuint		texture;
	Vector2*	textureCoords;
};