#pragma once

#include <string>
#include <iostream>
#include <fstream>

#include "mesh.h"

#define RAW_WIDTH	1081
#define RAW_HEIGHT	1081

#define HEIGHTMAP_X 8.0f
#define HEIGHTMAP_Z 8.0f
#define HEIGHTMAP_Y 8.0f
#define HEIGHTMAP_TEX_X 1.0f / 8.0f
#define HEIGHTMAP_TEX_Z 1.0f / 8.0f

#define HEIGHTMAP_COLOUR 1.0f;

class HeightMap : public Mesh
{
public:
	HeightMap(std::string name = NULL);
	~HeightMap() { }

	void SetOffset(float off) { offset = off; }
	float GetOffset() { return offset; }

	virtual void Draw();

	inline void SetSnowTex(GLuint tex) { snowTex = tex; snow = (tex > 0) ? true : false; }
	inline GLuint GetSnowTex() { return snowTex; }

	inline bool GetSnowState() { return snow; }

protected:
	GLuint snowTex;
	float offset;

	bool snow;
};
